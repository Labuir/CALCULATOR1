<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style4.css">
  <title>Document</title>
</head>
<body>
  <form method="post" >
    numb 1<input type="text" name="numb1" ></br>
    numb 2<input type="text" name="numb2" ></br>
    <input type="submit" value="+" name="op">
    <input type="submit" value="-" name="op">
    <input type="submit" value="/" name="op">
    <input type="submit" value="*" name="op"></br>
     resultat :
     <?php 
     if(isset($_POST['op']))
     {
       if($_POST['op']=='+')
       echo $_POST['numb1']+$_POST['numb2'];
       if($_POST['op']=='-')
       echo $_POST['numb1']-$_POST['numb2'];
       if($_POST['op']=='*')
       echo $_POST['numb1']*$_POST['numb2'];
       if($_POST['op']=='/')
       echo $_POST['numb1']/$_POST['numb2'];



     }
     ?>
    
    



</body>
</html>